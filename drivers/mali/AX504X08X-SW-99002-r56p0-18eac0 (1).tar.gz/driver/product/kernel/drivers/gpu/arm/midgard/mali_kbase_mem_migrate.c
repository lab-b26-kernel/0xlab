// SPDX-License-Identifier: GPL-2.0 WITH Linux-syscall-note
/*
 *
 * (C) COPYRIGHT 2022-2026 ARM Limited. All rights reserved.
 *
 * This program is free software and is provided to you under the terms of the
 * GNU General Public License version 2 as published by the Free Software
 * Foundation, and any use by you of this program is subject to the terms
 * of such GNU license.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, you can access it online at
 * http://www.gnu.org/licenses/gpl-2.0.html.
 *
 */

/**
 * DOC: Base kernel page migration implementation.
 */
#include <mali_kbase.h>
#include <mali_kbase_mem.h>
#include <mali_kbase_mem_migrate.h>
#include <mmu/mali_kbase_mmu.h>

/* Static key used to determine if page migration is enabled or not */
static DEFINE_STATIC_KEY_FALSE(page_migration_static_key);

/* -1 as default, 0 when manually set as off and 1 when manually set as on */
#ifdef __ANDROID_COMMON_KERNEL__
static int kbase_page_migration_enabled;
#else
static int kbase_page_migration_enabled = -1;
#endif /* __ANDROID_COMMON_KERNEL__ */
module_param(kbase_page_migration_enabled, int, 0444);
MODULE_PARM_DESC(kbase_page_migration_enabled,
		 "Explicitly enable or disable page migration with 1 or 0 respectively.");

#if MALI_UNIT_TEST
static void (*page_migration_test_hook)
	(enum kbase_page_migration_test_hook_point hook_point, struct page *old_page);

void kbase_page_migration_set_test_hook(void (*hook)
	(enum kbase_page_migration_test_hook_point hook_point, struct page *old_page))
{
	WRITE_ONCE(page_migration_test_hook, hook);
}

KBASE_EXPORT_TEST_API(kbase_page_migration_set_test_hook);

void kbase_page_migration_test_hook(enum kbase_page_migration_test_hook_point hook_point,
				    struct page *old_page)
{
	void (*hook)(enum kbase_page_migration_test_hook_point hook_point,
		     struct page *old_page) = READ_ONCE(page_migration_test_hook);

	if (hook)
		hook(hook_point, old_page);
}

KBASE_EXPORT_TEST_API(kbase_page_migration_test_hook);
#endif

void kbase_clear_page_movable(struct page *p)
{
#if (KERNEL_VERSION(6, 17, 0) > LINUX_VERSION_CODE)
	__ClearPageMovable(p);
#endif
}
KBASE_EXPORT_TEST_API(kbase_clear_page_movable);

#if (KERNEL_VERSION(6, 0, 0) <= LINUX_VERSION_CODE)
void kbase_set_page_movable(struct page *p, const struct movable_operations *ops)
{
#if (KERNEL_VERSION(6, 17, 0) <= LINUX_VERSION_CODE)
	__SetPageOffline(p);
	SetPageMovableOps(p);
	CSTD_UNUSED(ops);
#else
	__SetPageMovable(p, ops);
#endif
}
#endif

bool kbase_is_page_migration_enabled(void)
{
	return static_branch_unlikely(&page_migration_static_key);
}
KBASE_EXPORT_TEST_API(kbase_is_page_migration_enabled);

bool kbase_alloc_page_metadata(struct kbase_device *kbdev, struct page *p, dma_addr_t dma_addr,
			       u8 group_id)
{
	struct kbase_page_metadata *page_md;

	if (!kbase_is_page_migration_enabled())
		return false;

	/* Composite large-page is excluded from migration, trigger a warn if a development
	 * wrongly leads to it.
	 */
	if (is_huge_head(as_tagged(page_to_phys(p))) || is_partial(as_tagged(page_to_phys(p))))
		dev_WARN(kbdev->dev, "%s: migration-metadata attempted on large-page.", __func__);

	page_md = kmem_cache_zalloc(kbdev->page_metadata_slab, GFP_KERNEL);
	if (!page_md)
		return false;

	SetPagePrivate(p);
	set_page_private(p, (unsigned long)page_md);
	page_md->kbdev = kbdev;
	page_md->dma_addr = dma_addr;
	page_md->status = PAGE_STATUS_SET(page_md->status, (u8)ALLOCATE_IN_PROGRESS);
	page_md->vmap_count = 0;
	page_md->group_id = group_id;
	kbase_clear_page_metadata_kctx_id(page_md);
	spin_lock_init(&page_md->migrate_lock);
	sema_init(&page_md->cpu_map_lock, 1);

	lock_page(p);
#if (KERNEL_VERSION(6, 0, 0) <= LINUX_VERSION_CODE)
	kbase_set_page_movable(p, &movable_ops);
	page_md->status = PAGE_MOVABLE_SET(page_md->status);
#else
	/* In some corner cases, the driver may attempt to allocate memory pages
	 * even before the device file is open and the mapping for address space
	 * operations is created. In that case, it is impossible to assign address
	 * space operations to memory pages: simply pretend that they are movable,
	 * even if they are not.
	 *
	 * The page will go through all state transitions but it will never be
	 * actually considered movable by the kernel. This is due to the fact that
	 * the page cannot be marked as NOT_MOVABLE upon creation, otherwise the
	 * memory pool will always refuse to add it to the pool and schedule
	 * a worker thread to free it later.
	 *
	 * Page metadata may seem redundant in this case, but they are not,
	 * because memory pools expect metadata to be present when page migration
	 * is enabled and because the pages may always return to memory pools and
	 * gain the movable property later on in their life cycle.
	 */
	if (kbdev->mem_migrate.inode && kbdev->mem_migrate.inode->i_mapping) {
		__SetPageMovable(p, kbdev->mem_migrate.inode->i_mapping);
		page_md->status = PAGE_MOVABLE_SET(page_md->status);
	}
#endif
	unlock_page(p);

	return true;
}

static void kbase_free_page_metadata(struct kbase_device *kbdev, struct page *p, u8 *group_id)
{
	struct device *const dev = kbdev->dev;
	struct kbase_page_metadata *page_md;
	dma_addr_t dma_addr;

	if (!kbase_is_page_migration_enabled())
		return;

	page_md = kbase_page_private(p);
	if (!page_md)
		return;

	if (group_id)
		*group_id = page_md->group_id;
	dma_addr = kbase_dma_addr(p);
	dma_unmap_page(dev, dma_addr, PAGE_SIZE, DMA_BIDIRECTIONAL);

	kmem_cache_free(kbdev->page_metadata_slab, page_md);
	set_page_private(p, 0);
	ClearPagePrivate(p);
}

/* This function is only called when page migration
 * support is not explicitly compiled out.
 */
static void kbase_free_pages_worker(struct work_struct *work)
{
	struct kbase_mem_migrate *mem_migrate =
		container_of(work, struct kbase_mem_migrate, free_pages_work);
	struct kbase_device *kbdev = container_of(mem_migrate, struct kbase_device, mem_migrate);
	struct page *p, *tmp;
	struct kbase_page_metadata *page_md;
	LIST_HEAD(free_list);

	spin_lock(&mem_migrate->free_pages_lock);
	list_splice_init(&mem_migrate->free_pages_list, &free_list);
	spin_unlock(&mem_migrate->free_pages_lock);
	list_for_each_entry_safe(p, tmp, &free_list, lru) {
		u8 group_id = 0;
		list_del_init(&p->lru);

		lock_page(p);
		page_md = kbase_page_private(p);
		if (page_md && IS_PAGE_MOVABLE(page_md->status)) {
			kbase_clear_page_movable(p);
			page_md->status = PAGE_MOVABLE_CLEAR(page_md->status);
		}
		kbase_free_page_metadata(kbdev, p, &group_id);
		unlock_page(p);
		kbdev->mgm_dev->ops.mgm_free_page(kbdev->mgm_dev, group_id, p, 0);
	}
}

void kbase_free_page_later(struct kbase_device *kbdev, struct page *p)
{
	struct kbase_mem_migrate *mem_migrate = &kbdev->mem_migrate;

	if (!kbase_is_page_migration_enabled())
		return;

	spin_lock(&mem_migrate->free_pages_lock);
	list_add(&p->lru, &mem_migrate->free_pages_list);
	spin_unlock(&mem_migrate->free_pages_lock);
}

/**
 * kbasep_migrate_page_pt_mapped - Migrate a memory page that is mapped
 *                                 in a PGD of kbase_mmu_table.
 *
 * @old_page:  Existing PGD page to remove
 * @new_page:  Destination for migrating the existing PGD page to
 *
 * Replace an existing PGD page with a new page by migrating its content. More specifically:
 * the new page shall replace the existing PGD page in the MMU page table. Before returning,
 * the new page shall be set as movable and not isolated, while the old page shall lose
 * the movable property. The meta data attached to the PGD page is transferred to the
 * new (replacement) page.
 *
 * This function returns early with an error if called when page migration is disabled.
 *
 * Return: 0 on migration success, or -EAGAIN for a later retry. Otherwise it's a failure
 *          and the migration is aborted.
 */
static int kbasep_migrate_page_pt_mapped(struct page *old_page, struct page *new_page)
{
	struct kbase_page_metadata *page_md = kbase_page_private(old_page);
	struct kbase_device *kbdev;
	dma_addr_t old_dma_addr, new_dma_addr;
	int ret;

	if (!kbase_is_page_migration_enabled())
		return -EINVAL;

	spin_lock(&page_md->migrate_lock);

	if (PAGE_STATUS_GET(page_md->status) == FREE_PT_ISOLATED_IN_PROGRESS) {
		ret = -EAGAIN;
		goto early_exit;
	}

	if (WARN_ONCE(PAGE_STATUS_GET(page_md->status) != PT_MAPPED,
		      "Page metadata status %d doesn't match expected value %d",
		      PAGE_STATUS_GET(page_md->status), PT_MAPPED)) {
		ret = -EINVAL;
		goto early_exit;
	}

	kbdev = page_md->kbdev;
	old_dma_addr = page_md->dma_addr;

	spin_unlock(&page_md->migrate_lock);
	kbase_page_migration_test_hook(KBASE_PM_TEST_HOOK_PT_MAPPED_AFTER_MD,
				       old_page);

	/* Defer the migration action if deferral condition exists */
	if (kbase_mem_is_pmode_deferral_required(kbdev))
		return -EAGAIN;

	/* Create a new dma map for the new page */
	new_dma_addr = dma_map_page(kbdev->dev, new_page, 0, PAGE_SIZE, DMA_BIDIRECTIONAL);
	if (dma_mapping_error(kbdev->dev, new_dma_addr))
		return -ENOMEM;

	ret = kbase_mmu_migrate_pgd_page(as_tagged(page_to_phys(old_page)),
					 as_tagged(page_to_phys(new_page)), old_dma_addr,
					 new_dma_addr);

	if (ret == 0) {
		dma_unmap_page(kbdev->dev, old_dma_addr, PAGE_SIZE, DMA_BIDIRECTIONAL);
		kbase_clear_page_movable(old_page);
		ClearPagePrivate(old_page);
		put_page(old_page);

#if (KERNEL_VERSION(6, 0, 0) <= LINUX_VERSION_CODE)
		kbase_set_page_movable(new_page, &movable_ops);
		spin_lock(&page_md->migrate_lock);
		page_md->status = PAGE_MOVABLE_SET(page_md->status);
		spin_unlock(&page_md->migrate_lock);
#else
		if (kbdev->mem_migrate.inode->i_mapping) {
			__SetPageMovable(new_page, kbdev->mem_migrate.inode->i_mapping);
			spin_lock(&page_md->migrate_lock);
			page_md->status = PAGE_MOVABLE_SET(page_md->status);
			spin_unlock(&page_md->migrate_lock);
		}
#endif
		SetPagePrivate(new_page);
		set_page_private(new_page, (unsigned long)page_md);
		get_page(new_page);
	} else
		dma_unmap_page(kbdev->dev, new_dma_addr, PAGE_SIZE, DMA_BIDIRECTIONAL);

	return ret;

early_exit:
	spin_unlock(&page_md->migrate_lock);
	return ret;
}

/*
 * kbasep_migrate_page_allocated_mapped - Migrate a memory page that is both
 *                                        allocated and mapped.
 *
 * @old_page:  Page to remove.
 * @new_page:  Page to add.
 *
 * Replace an old page with a new page by migrating its content and all its
 * CPU and GPU mappings. More specifically: the new page shall replace the
 * old page in the MMU page table, as well as in the page array of the physical
 * allocation, which is used to create CPU mappings. Before returning, the new
 * page shall be set as movable and not isolated, while the old page shall lose
 * the movable property.
 *
 * This function returns early with an error if called when page migration is disabled.
 */
static int kbasep_migrate_page_allocated_mapped(struct page *old_page, struct page *new_page)
{
	struct kbase_page_metadata *page_md = kbase_page_private(old_page);
	struct kbase_device *kbdev;
	dma_addr_t old_dma_addr, new_dma_addr;
	u64 vpfn;
	int ret;
	struct file *filp;

	if (!kbase_is_page_migration_enabled())
		return -EINVAL;

	spin_lock(&page_md->migrate_lock);

	if (PAGE_STATUS_GET(page_md->status) == FREE_ISOLATED_IN_PROGRESS) {
		ret = -EAGAIN;
		goto early_exit;
	}

	if (WARN_ONCE(PAGE_STATUS_GET(page_md->status) != ALLOCATED_MAPPED,
		      "Page metadata status %d doesn't match expected value %d",
		      PAGE_STATUS_GET(page_md->status), ALLOCATED_MAPPED)) {
		ret = -EINVAL;
		goto early_exit;
	}

	kbdev = page_md->kbdev;
	old_dma_addr = page_md->dma_addr;
	vpfn = page_md->data.mapped.vpfn;
	filp = page_md->data.mapped.mmut->kctx->filp;

	spin_unlock(&page_md->migrate_lock);
	kbase_page_migration_test_hook(KBASE_PM_TEST_HOOK_ALLOC_MAPPED_AFTER_MD,
				       old_page);

	/* Defer the migration action if deferral condition exists */
	if (kbase_mem_is_pmode_deferral_required(kbdev)) {
		ret = -EAGAIN;
		goto err_exit;
	}

	/* Create a new dma map for the new page */
	new_dma_addr = dma_map_page(kbdev->dev, new_page, 0, PAGE_SIZE, DMA_BIDIRECTIONAL);
	if (dma_mapping_error(kbdev->dev, new_dma_addr)) {
		ret = -ENOMEM;
		goto err_exit;
	}

	/* Synchronize with the VM fault() function and then
	 * unmap the old physical range. After that, we can
	 * release the reference to the mali device file and
	 * migrate the data in the page.
	 */
	down(&page_md->cpu_map_lock);
	unmap_mapping_range(filp->f_inode->i_mapping,
			    (loff_t)(vpfn / GPU_PAGES_PER_CPU_PAGE) << PAGE_SHIFT, PAGE_SIZE, 1);

	ret = kbase_mmu_migrate_data_page(as_tagged(page_to_phys(old_page)),
					  as_tagged(page_to_phys(new_page)), old_dma_addr,
					  new_dma_addr);
	up(&page_md->cpu_map_lock);

	if (ret == 0) {
		dma_unmap_page(kbdev->dev, old_dma_addr, PAGE_SIZE, DMA_BIDIRECTIONAL);

		SetPagePrivate(new_page);
		set_page_private(new_page, (unsigned long)page_md);
		get_page(new_page);

		/* Clear PG_movable from the old page and release reference. */
		ClearPagePrivate(old_page);
		kbase_clear_page_movable(old_page);
		put_page(old_page);

		/* Set PG_movable to the new page. */
#if (KERNEL_VERSION(6, 0, 0) <= LINUX_VERSION_CODE)
		kbase_set_page_movable(new_page, &movable_ops);
		spin_lock(&page_md->migrate_lock);
		page_md->status = PAGE_MOVABLE_SET(page_md->status);
		spin_unlock(&page_md->migrate_lock);
#else
		if (kbdev->mem_migrate.inode->i_mapping) {
			__SetPageMovable(new_page, kbdev->mem_migrate.inode->i_mapping);
			spin_lock(&page_md->migrate_lock);
			page_md->status = PAGE_MOVABLE_SET(page_md->status);
			spin_unlock(&page_md->migrate_lock);
		}
#endif
	} else
		dma_unmap_page(kbdev->dev, new_dma_addr, PAGE_SIZE, DMA_BIDIRECTIONAL);

err_exit:
	return ret;

early_exit:
	spin_unlock(&page_md->migrate_lock);
	return ret;
}

#if MALI_UNIT_TEST
int kbase_migrate_page_allocated_mapped(struct page *old_page, struct page *new_page)
{
	return kbasep_migrate_page_allocated_mapped(old_page, new_page);
}
KBASE_EXPORT_TEST_API(kbase_migrate_page_allocated_mapped);
#endif

static bool bump_up_active_file_ref_count(struct kbase_context *kctx)
{
	bool bumped_up = false;

/* v4.9 - v6.6: f_count exists; v6.7+ use get_file_active(). */
#if (KERNEL_VERSION(6, 7, 0) > LINUX_VERSION_CODE)
	if (!atomic_long_inc_not_zero(&kctx->filp->f_count))
		bumped_up = false;
	else
		bumped_up = true;
#else
	if (!get_file_active(&kctx->filp))
		bumped_up = false;
	else
		bumped_up = true;
#endif

	return bumped_up;
}

/**
 * block_kctx_destruction - Block kbase context destruction during page migration
 *
 * @kbdev: Pointer to kbase device.
 * @kctx_id: Context id to look up in the device list.
 * @blocked_kctx: Pointer to the blocked kbase context.
 *
 * Search the kbase context using kctx id from the kbase device list, @kctx_list_link.
 * If found and the corresponding file isn't yet released, increase its reference count
 * to block file release and kctx destruction.
 * The found kctx is returned via @blocked_kctx. Later on allow_kctx_destruction()
 * will decrease the reference count after page migration is done.
 *
 * If file release operation is racing with page migration and kctx is still in the list
 * but the file reference count is zero or doesn't exist in the list return false to abort
 * page migration. If the page is device level, abort page migration.
 *
 * Return: 0 if page migration can proceed
 *         error code if page migration should abort or if page is device level
 */
static int block_kctx_destruction(struct kbase_device *kbdev, u32 kctx_id,
				  struct kbase_context **blocked_kctx)
{
	struct kbase_context *kctx;
	bool kctx_found_in_list = false;
	int result = 0;

	/* Abort page migration for device level page */
	if (kctx_id == RESERVED_CONTEXT_ID)
		return -EINVAL;

	mutex_lock(&kbdev->kctx_list_lock);

	list_for_each_entry(kctx, &kbdev->kctx_list, kctx_list_link) {
		if (kctx->id == kctx_id) {
			kctx_found_in_list = true;
			if (bump_up_active_file_ref_count(kctx))
				*blocked_kctx = kctx;
			else
				result = -EINVAL;
			break;
		}
	}

	/* If kctx is in the device list and its ref. count is successfully increased
	 * page migration can proceed. Otherwise abort page migration.
	 */
	if (!kctx_found_in_list)
		result = -EINVAL;

	mutex_unlock(&kbdev->kctx_list_lock);

	return result;
}

/**
 * allow_kctx_destruction - Allow kbase context destruction after page migration is done
 *
 * @kctx: Pointer to kbase context
 *
 * Decrease the kctx file reference count increased by block_kctx_destruction.
 */
static void allow_kctx_destruction(struct kbase_context *kctx)
{
	if (kctx)
		fput(kctx->filp);
}

/**
 * kbase_page_isolate - Isolate a page for migration.
 *
 * @p:    Pointer of the page struct of page to isolate.
 * @mode: LRU Isolation modes.
 *
 * Callback function for Linux to isolate a page and prepare it for migration.
 * This callback is not registered if page migration is disabled.
 *
 * Return: true on success, false otherwise.
 */
static bool kbase_page_isolate(struct page *p, isolate_mode_t mode)
{
	bool status_mem_pool = false;
	struct kbase_mem_pool *mem_pool = NULL;
	struct kbase_page_metadata *page_md = kbase_page_private(p);
	struct kbase_mmu_table *mmut = NULL;
	struct kbase_device *kbdev = NULL;

	if (!kbase_is_page_migration_enabled())
		return false;

	CSTD_UNUSED(mode);

	if (!page_md || !IS_PAGE_MOVABLE(page_md->status))
		return false;

	if (!spin_trylock(&page_md->migrate_lock))
		return false;

	if (WARN_ON(IS_PAGE_ISOLATED(page_md->status))) {
		spin_unlock(&page_md->migrate_lock);
		return false;
	}

	kbdev = page_md->kbdev;

	switch (PAGE_STATUS_GET(page_md->status)) {
	case MEM_POOL:
		/* Prepare to remove page from memory pool later only if pool is not
		 * in the process of termination.
		 */
		mem_pool = page_md->data.mem_pool.pool;
		status_mem_pool = true;
		preempt_disable();
		atomic_inc(&mem_pool->isolation_in_progress_cnt);
		break;
	case ALLOCATED_MAPPED:
		mmut = page_md->data.mapped.mmut;

		/* kctx can be NULL for a device-level (mcu) mapping */
		if (!mmut->kctx) {
			spin_unlock(&page_md->migrate_lock);
			return false;
		}

		if (page_md->vmap_count == 0 && !kbase_mem_is_pmode_deferral_required(kbdev))
			page_md->status = PAGE_ISOLATE_SET(page_md->status, 1);
		break;
	case PT_MAPPED:
		mmut = page_md->data.pt_mapped.mmut;

		/* kctx can be NULL for a device-level (mcu) mapping */
		if (!mmut->kctx) {
			spin_unlock(&page_md->migrate_lock);
			return false;
		}

		if (!kbase_mem_is_pmode_deferral_required(kbdev))
			page_md->status = PAGE_ISOLATE_SET(page_md->status, 1);
		break;
	case SPILL_IN_PROGRESS:
	case ALLOCATE_IN_PROGRESS:
	case FREE_IN_PROGRESS:
		break;
	case NOT_MOVABLE:
		/* Opportunistically clear the movable property for these pages */
		kbase_clear_page_movable(p);
		page_md->status = PAGE_MOVABLE_CLEAR(page_md->status);
		break;
	default:
		/* State should always fall in one of the previous cases!
		 * Also notice that FREE_ISOLATED_IN_PROGRESS or
		 * FREE_PT_ISOLATED_IN_PROGRESS is impossible because
		 * that state only applies to pages that are already isolated.
		 */
		page_md->status = PAGE_ISOLATE_SET(page_md->status, 0);
		break;
	}

	spin_unlock(&page_md->migrate_lock);

	/* If the page is still in the memory pool try to remove it. This will fail
	 * if pool lock is taken which could mean page no longer exists in pool.
	 */
	if (status_mem_pool) {
		if (!spin_trylock(&mem_pool->pool_lock)) {
			atomic_dec(&mem_pool->isolation_in_progress_cnt);
			preempt_enable();
			return false;
		}

		spin_lock(&page_md->migrate_lock);
		/* Check status again to ensure page has not been removed from memory pool,
		 * together with the condition that no pmode deferral needed.
		 */
		if (PAGE_STATUS_GET(page_md->status) == MEM_POOL &&
		    !kbase_mem_is_pmode_deferral_required(kbdev)) {
			page_md->status = PAGE_ISOLATE_SET(page_md->status, 1);
			list_del_init(&p->lru);
			mem_pool->cur_size--;
		}
		spin_unlock(&page_md->migrate_lock);
		spin_unlock(&mem_pool->pool_lock);
		atomic_dec(&mem_pool->isolation_in_progress_cnt);
		preempt_enable();
	}

	return IS_PAGE_ISOLATED(page_md->status);
}

/**
 * kbase_page_migrate - Migrate content of old page to new page provided.
 *
 * @mapping:  Pointer to address_space struct associated with pages.
 * @new_page: Pointer to the page struct of new page.
 * @old_page: Pointer to the page struct of old page.
 * @mode:     Mode to determine if migration will be synchronized.
 *
 * Callback function for Linux to migrate the content of the old page to the
 * new page provided.
 * This callback is not registered if page migration is disabled.
 * Block file release (context destruction) until migration is done.
 * If file release is already started, abort migration.
 *
 * Return: 0 on success, error code otherwise.
 */
#if (KERNEL_VERSION(6, 0, 0) > LINUX_VERSION_CODE)
static int kbase_page_migrate(struct address_space *mapping, struct page *new_page,
			      struct page *old_page, enum migrate_mode mode)
#else
static int kbase_page_migrate(struct page *new_page, struct page *old_page, enum migrate_mode mode)
#endif
{
	int err = 0;
	bool status_mem_pool = false;
	bool status_free_pt_isolated_in_progress = false;
	bool status_free_isolated_in_progress = false;
	bool status_pt_mapped = false;
	bool status_mapped = false;
	bool status_not_movable = false;
	struct kbase_page_metadata *page_md = kbase_page_private(old_page);
	struct kbase_device *kbdev = NULL;
	struct kbase_context *blocked_kctx = NULL;

#if (KERNEL_VERSION(6, 0, 0) > LINUX_VERSION_CODE)
	CSTD_UNUSED(mapping);
#endif
	CSTD_UNUSED(mode);

	if (!kbase_is_page_migration_enabled() || !page_md || !IS_PAGE_MOVABLE(page_md->status))
		return -EINVAL;

	if (!spin_trylock(&page_md->migrate_lock))
		return -EAGAIN;

	if (WARN_ON(!IS_PAGE_ISOLATED(page_md->status))) {
		spin_unlock(&page_md->migrate_lock);
		return -EINVAL;
	}

	kbdev = page_md->kbdev;

	switch (PAGE_STATUS_GET(page_md->status)) {
	case MEM_POOL:
		status_mem_pool = true;
		break;
	case ALLOCATED_MAPPED:
		status_mapped = true;
		break;
	case PT_MAPPED:
		status_pt_mapped = true;
		break;
	case FREE_ISOLATED_IN_PROGRESS:
		status_free_isolated_in_progress = true;
		break;
	case FREE_PT_ISOLATED_IN_PROGRESS:
		status_free_pt_isolated_in_progress = true;
		break;
	case NOT_MOVABLE:
		status_not_movable = true;
		break;
	default:
		/* State should always fall in one of the previous cases! */
		err = -EAGAIN;
		break;
	}

	spin_unlock(&page_md->migrate_lock);
	kbase_page_migration_test_hook(KBASE_PM_TEST_HOOK_PAGE_MIGRATE_AFTER_STATUS,
				       old_page);

	if (status_mem_pool || status_free_isolated_in_progress ||
	    status_free_pt_isolated_in_progress) {
		struct kbase_mem_migrate *mem_migrate = &kbdev->mem_migrate;

		kbase_free_page_metadata(kbdev, old_page, NULL);
		kbase_clear_page_movable(old_page);
		put_page(old_page);

		/* Just free new page to avoid lock contention. */
		INIT_LIST_HEAD(&new_page->lru);
		get_page(new_page);
		set_page_private(new_page, 0);
		kbase_free_page_later(kbdev, new_page);
		queue_work(mem_migrate->free_pages_workq, &mem_migrate->free_pages_work);
	} else if (status_not_movable) {
		err = -EINVAL;
	} else if (status_mapped) {
		if (block_kctx_destruction(kbdev, page_md->data.mapped.kctx_id, &blocked_kctx))
			return -EINVAL;
		err = kbasep_migrate_page_allocated_mapped(old_page, new_page);
	} else if (status_pt_mapped) {
		if (block_kctx_destruction(kbdev, page_md->data.pt_mapped.kctx_id, &blocked_kctx))
			return -EINVAL;
		err = kbasep_migrate_page_pt_mapped(old_page, new_page);
	}

	/* While we want to preserve the movability of pages for which we return
	 * EAGAIN, according to the kernel docs, movable pages for which a critical
	 * error is returned are called putback on, which may not be what we
	 * expect.
	 */
	if (err < 0 && err != -EAGAIN) {
		kbase_clear_page_movable(old_page);
		page_md->status = PAGE_MOVABLE_CLEAR(page_md->status);
	}

	allow_kctx_destruction(blocked_kctx);

	return err;
}

/**
 * kbase_page_putback - Return isolated page back to kbase.
 *
 * @p: Pointer of the page struct of page.
 *
 * Callback function for Linux to return isolated page back to kbase. This
 * will only be called for a page that has been isolated but failed to
 * migrate. This function will put back the given page to the state it was
 * in before it was isolated.
 * This callback is not registered if page migration is disabled.
 */
static void kbase_page_putback(struct page *p)
{
	bool status_mem_pool = false;
	bool status_free_isolated_in_progress = false;
	bool status_free_pt_isolated_in_progress = false;
	struct kbase_page_metadata *page_md = kbase_page_private(p);
	struct kbase_device *kbdev = NULL;

	if (!kbase_is_page_migration_enabled())
		return;

	/* If we don't have page metadata, the page may not belong to the
	 * driver or may already have been freed, and there's nothing we can do
	 */
	if (!page_md)
		return;

	spin_lock(&page_md->migrate_lock);

	if (WARN_ON(!IS_PAGE_ISOLATED(page_md->status))) {
		spin_unlock(&page_md->migrate_lock);
		return;
	}

	kbdev = page_md->kbdev;

	switch (PAGE_STATUS_GET(page_md->status)) {
	case MEM_POOL:
		status_mem_pool = true;
		break;
	case ALLOCATED_MAPPED:
		page_md->status = PAGE_ISOLATE_SET(page_md->status, 0);
		break;
	case PT_MAPPED:
	case NOT_MOVABLE:
		/* Pages should no longer be isolated if they are in a stable state
		 * and used by the driver.
		 */
		page_md->status = PAGE_ISOLATE_SET(page_md->status, 0);
		break;
	case FREE_ISOLATED_IN_PROGRESS:
		status_free_isolated_in_progress = true;
		break;
	case FREE_PT_ISOLATED_IN_PROGRESS:
		status_free_pt_isolated_in_progress = true;
		break;
	default:
		/* State should always fall in one of the previous cases! */
		break;
	}

	spin_unlock(&page_md->migrate_lock);

	/* If page was in a memory pool then just free it to avoid lock contention. The
	 * same is also true to status_free_pt_isolated_in_progress.
	 */
	if (status_mem_pool || status_free_isolated_in_progress ||
	    status_free_pt_isolated_in_progress) {
		kbase_clear_page_movable(p);
		page_md->status = PAGE_MOVABLE_CLEAR(page_md->status);
		if (!WARN_ON_ONCE(!kbdev)) {
			struct kbase_mem_migrate *mem_migrate = &kbdev->mem_migrate;

			kbase_free_page_later(kbdev, p);
			queue_work(mem_migrate->free_pages_workq, &mem_migrate->free_pages_work);
		}
	}
}

#if (KERNEL_VERSION(6, 0, 0) <= LINUX_VERSION_CODE)
const struct movable_operations movable_ops = {
	.isolate_page = kbase_page_isolate,
	.migrate_page = kbase_page_migrate,
	.putback_page = kbase_page_putback,
};
EXPORT_SYMBOL(movable_ops);
#else
static const struct address_space_operations kbase_address_space_ops = {
	.isolate_page = kbase_page_isolate,
	.migratepage = kbase_page_migrate,
	.putback_page = kbase_page_putback,
};
#endif

#if (KERNEL_VERSION(6, 0, 0) > LINUX_VERSION_CODE)
void kbase_mem_migrate_set_address_space_ops(struct kbase_device *kbdev, struct file *const filp)
{
	if (!kbase_is_page_migration_enabled())
		return;

	mutex_lock(&kbdev->fw_load_lock);

	if (filp) {
		filp->f_inode->i_mapping->a_ops = &kbase_address_space_ops;

		if (!kbdev->mem_migrate.inode) {
			kbdev->mem_migrate.inode = filp->f_inode;
			/* This reference count increment is balanced by iput()
			 * upon termination.
			 */
			atomic_inc(&filp->f_inode->i_count);
		} else {
			WARN_ON(kbdev->mem_migrate.inode != filp->f_inode);
		}
	}

	mutex_unlock(&kbdev->fw_load_lock);
}
#endif

void kbase_mem_migrate_init(struct kbase_device *kbdev)
{
	struct kbase_mem_migrate *mem_migrate = &kbdev->mem_migrate;

#ifdef CONFIG_MALI_PAGE_MIGRATION
#ifdef __ANDROID_COMMON_KERNEL__
	#error "Mali does not support page migration on Android"
#endif /* __ANDROID_COMMON_KERNEL__ */

	/* Issue a compile time message that the feature is for EXPERIMENTAL use only*/
	 #pragma message("WARNING: Mali page migration feature is for EXPERIMENTAL use only")

	/* Page migration should only be enabled if compaction is
	 * enabled in the kernel otherwise pages cannot be marked as
	 * movable.
	 *
	 * Page migration support compiled in, either explicitly or
	 * by default, so the default behaviour is to follow the choice
	 * of large pages if not selected at insmod. Check insmod parameter
	 * integer for a negative value to see if insmod parameter was
	 * passed in at all (it will override the default negative value).
	 */
	if (IS_ENABLED(CONFIG_COMPACTION)) {
		if (kbase_page_migration_enabled < 0) {
			if (kbase_is_large_pages_enabled())
				static_branch_inc(&page_migration_static_key);
		} else {
			dev_info(kbdev->dev, "Page migration support explicitly %s at insmod.",
				 kbase_page_migration_enabled ? "enabled" : "disabled");
			if (kbase_page_migration_enabled)
				static_branch_inc(&page_migration_static_key);
		}

		if (kbase_is_page_migration_enabled())
			dev_warn(kbdev->dev,
				"Mali page migration feature is for EXPERIMENTAL use only.");

	} else if (kbase_page_migration_enabled) {
		dev_warn(kbdev->dev,
			 "No CONFIG_COMPACTION. 'page migration support enable' ignored.");
	}
#endif /* CONFIG_MALI_PAGE_MIGRATION */

	spin_lock_init(&mem_migrate->free_pages_lock);
	INIT_LIST_HEAD(&mem_migrate->free_pages_list);

	mem_migrate->free_pages_workq =
		alloc_workqueue("free_pages_workq", WQ_UNBOUND | WQ_MEM_RECLAIM, 1);
	INIT_WORK(&mem_migrate->free_pages_work, kbase_free_pages_worker);
}

void kbase_mem_migrate_term(struct kbase_device *kbdev)
{
	struct kbase_mem_migrate *mem_migrate = &kbdev->mem_migrate;

	if (mem_migrate->free_pages_workq)
		destroy_workqueue(mem_migrate->free_pages_workq);
#if (KERNEL_VERSION(6, 0, 0) > LINUX_VERSION_CODE)
	iput(mem_migrate->inode);
#endif
}
